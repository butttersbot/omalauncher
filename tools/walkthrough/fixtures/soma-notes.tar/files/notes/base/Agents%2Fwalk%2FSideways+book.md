# Sideways book

A sample note for reading two pages at a time on an unfolded phone held sideways. It has headings, paragraphs, a list, a table and a code block, so every kind of block lands somewhere on the page spread. None of it is about anyone in particular.

## Chapter one: The lighthouse keeper's ledger

The lighthouse stood at the end of a long spit of grey stone, and the keeper kept a ledger of everything that passed. Ships, mostly, but also weather, birds, the colour of the sea at dawn and the number of steps it took to climb the tower when his knees were bad. The ledger was not required by anyone. The harbour office asked only for a monthly report of the lamp's hours and the oil it burned. The rest he wrote because writing it made the days distinct from one another, and on an island where every day looked much like the last, that mattered more than he could easily explain.

He wrote in a small, careful hand, with the date in the left margin and the hour beside it. When a ship passed he noted its flag, its rough tonnage, the direction it was heading and whether it answered the lamp with a signal of its own. Most did not. The big freighters ran on schedules set a continent away, and their crews had little reason to wave at a tower they would never see again. The fishing boats were different. They knew the light, and some of them knew the keeper, and on calm evenings a horn would sound twice across the water as they turned for home.

On the first page of every new ledger he copied out the same three lines: the latitude and longitude of the tower, the height of the lamp above the mean high tide, and the distance at which the light could be seen on a clear night. He did not need to copy them. He knew them by heart. But a ledger without them felt unfinished, like a letter without an address.

## Chapter two: Weather, written down

Weather was the second great subject of the ledger, and it took up more pages than the ships. The keeper had a barometer, a thermometer in a slatted box on the north wall and a wind vane on the gallery rail. He read them at six, at noon and at six again, and he wrote down what they said and what he thought they meant.

Over the years he learned that the instruments told only part of the story. The barometer could fall for a day without a drop of rain, and a squall could come out of a clear sky with no warning at all. So he began to note the other signs: the way the gulls stopped wheeling and sat in rows on the rocks, the smell of the air before a storm, the long low swell that sometimes arrived a full day before the wind that made it.

He kept a short list at the back of each ledger, the signs he trusted most:

- Gulls settling on the rocks in the middle of the day.
- A ring around the moon, especially a wide one.
- Swell from the south-west with no wind behind it.
- The far headland looking closer than it should.
- Smoke from the village chimneys lying flat instead of rising.

None of these were certain. Taken together, and written down every day for years, they were better than certain. They were familiar.

## Chapter three: The supply boat

Once a fortnight, weather permitting, the supply boat came out from the mainland. It brought oil for the lamp, flour, tinned food, letters, newspapers a week old and whatever small things the keeper had asked for in his last letter: a new pen nib, a tin of tobacco, a book.

The arrival of the boat was the one fixed point in the calendar, and the ledger recorded it in more detail than anything else. What came, what went back, who was aboard, what news they brought. Over time these entries became a kind of history of the mainland as seen from the island, told in fragments: a new harbour master, a bad winter for the herring, a wedding, a fire at the cannery, the price of oil going up and then, years later, coming down again.

The table below is copied from one year of those entries, tidied a little.

| Month     | Boat days | Missed for weather | Oil delivered (gallons) | Letters received |
|-----------|-----------|--------------------|-------------------------|------------------|
| January   | 1         | 1                  | 40                      | 3                |
| February  | 2         | 0                  | 80                      | 5                |
| March     | 2         | 0                  | 80                      | 4                |
| April     | 2         | 0                  | 70                      | 6                |
| May       | 2         | 0                  | 60                      | 2                |
| June      | 2         | 0                  | 50                      | 7                |
| July      | 2         | 0                  | 50                      | 4                |
| August    | 2         | 0                  | 50                      | 3                |
| September | 2         | 0                  | 60                      | 5                |
| October   | 1         | 1                  | 40                      | 2                |
| November  | 1         | 1                  | 40                      | 4                |
| December  | 1         | 1                  | 40                      | 9                |

December's letters were mostly cards. The keeper kept them on the windowsill of the lamp room until the end of January, and then he put them in a biscuit tin with all the others.

## Chapter four: Keeping count

In his later years the keeper became interested in the ledgers themselves as a record, and he began to count things across them. How many ships in a year, and whether the number was rising or falling. How many days of fog. How many times the supply boat had been late. He did this with a pencil and a sheet of squared paper, and it took him most of a winter.

His grandson, who visited one summer and was good with machines, showed him how the same count could be done in a few lines on a small computer. The keeper was not convinced it was an improvement, but he copied the lines into the back of the ledger anyway, because they were tidy and because the boy had been proud of them.

```python
from collections import Counter

def ships_per_year(entries):
    """Count ship sightings per year from (date, kind) pairs."""
    counts = Counter()
    for date, kind in entries:
        if kind == "ship":
            counts[date.year] += 1
    return dict(sorted(counts.items()))

def foggy_days(entries):
    """The days on which fog was noted at least once."""
    return sorted({date for date, kind in entries if kind == "fog"})
```

He never ran it. But he liked knowing that the ledgers could be read that way too, by something that did not get tired and did not lose its place.

## Chapter five: The lamp

The lamp itself was the reason for everything else, and the keeper treated it with something close to reverence. Every morning, after the light was put out, he cleaned the lens. It was a great beehive of glass prisms, taller than he was, and each prism had to be wiped with a soft cloth and a little spirit, working from the top down so that nothing dripped onto a surface already cleaned. It took the better part of an hour.

Then he trimmed the wick, refilled the reservoir and wound the clockwork that turned the lens. The clockwork was old and needed winding every four hours through the night, which meant the keeper never slept for more than four hours at a stretch. He had done this for so long that he woke before the alarm, every time, and lay for a minute listening to the slow tick of the mechanism before he climbed the stairs.

On the rare nights when something went wrong, a cracked chimney glass or a wick that would not draw, he wrote it down in red ink. There were not many red entries in the ledgers. He was proud of that, in a quiet way, and when the inspector came each spring he would turn to the pages with red ink first and explain each one.

## Chapter six: Leaving

When the light was finally automated, the keeper was given a month's notice and a small pension. The new lamp was electric and turned itself on and off, and the clockwork was taken out and sent to a museum. The ledgers he was allowed to keep.

He packed them into two tea chests and took them with him on the last supply boat. He did not look back at the tower as the boat pulled away, or so he said afterwards. The crew said otherwise, but they were kind enough not to argue.

In the small house he took on the mainland, the ledgers went on a shelf in the front room, in order, with the dates written on their spines. He still woke every four hours for the first year. He still noted the weather at six, at noon and at six again, in a new ledger, though there was no lamp to keep and no ships to count. Old habits, he would say, are just the shape a life has worn into you.

## A note on reading this

This piece exists to fill pages. On an unfolded phone held sideways it should run across at least four pages when two are shown side by side: the headings should start new thoughts without starting new pages, the list and the table should stay readable, and the code block should scroll or wrap rather than run off the edge. If any of those break, that's what this note is for.
