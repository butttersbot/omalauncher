# Brief

A read-only test note for the emulator walks. It is mirrored, not stored: PUT and DELETE on it answer 403.
